let jasonaudio1 = () => {
    let audio1 = document.getElementById("audio1");
    audio1.play()
}
let jasonaudio2 = () => {
    let audio2 = document.getElementById("audio2");
    audio2.play()
}
let jasonaudio3 = () => {
    let audio3 = document.getElementById("audio3");
    audio3.play()
}
let jasonaudio4 = () => {
    let audio4 = document.getElementById("audio4");
    audio4.play()
}
let jasonaudio5 = () => {
    let audio5 = document.getElementById("audio5");
    audio5.play()
}
let jasonaudio6 = () => {
    let audio6 = document.getElementById("audio6");
    audio6.play()
}
let jasonaudio7 = () => {
    let audio7 = document.getElementById("audio7");
    audio7.play()
}
let jasonaudio8 = () => {
    let audio8 = document.getElementById("audio8");
    audio8.play()
}
let jasonaudio9 = () => {
    let audio9 = document.getElementById("audio9");
    audio9.play()
}
let risaaudio = () => {
    let audiorisa = document.getElementById("audiorisa");
    audiorisa.play()
}